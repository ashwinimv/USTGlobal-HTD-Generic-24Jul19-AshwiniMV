window.alert("hello");
alert("hiiiiiiiii");

let isAdult = confirm("Are u adilt");
console.log("Is adult ="+isAdult);

let name=prompt("what is your name");/* prompt take data from user*/
console.log("Name is ="+name);


