// function validate(){
//     let employeeData = document.forms['employeeForm'];
//     let empPassword = employeeData.pass.value;
//     let empCPassword = employeeData.cpass.value;
//     if(empPassword==='' && empCPassword===''){
//         return false;
//     }
//     else if(empPassword === empCPassword)
//     {
//         alert('success');
//         return true;
      
//     }
//     else{
//         alert("password not matching");
//         return false;
//     }

// }


let employeeData = new Promise(function(resolve,reject){
    const employee = [
        {
            name : 'Shahrukh',
            age : 60
        },
        {
            name : 'sundari',
            age:45
        },
        {
            name : 'Akshay',
            age : 50
        }
    ];
    if(10>10){
        reject('Failes'); //if we comment the reject and resolve then it go pending state;
    }else{
        resolve(employee);
    }
});

employeeData.then((data)=>{
    console.log('Then block ='+data);
}).catch((error)=>{
    console.log('catch block='+error);
});
