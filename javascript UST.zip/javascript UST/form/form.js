function validateForm(){
    let formData = document.forms[0];
    // console.log(formData);
    // console.log(formData.uname.value);//it give output succes after 5leeters

    let userName = formData.uname.value;
    let passwordValue= formData.passwrd.value;
    if(userName.length>4 && passwordValue.length>4)
    {
        // console.log('Success');
        formData.uname.style.border='4px solid green';
        formData.passwrd.style.border='4px solid green';
        formData.loginSubmit.disabled=false;
        // formData.uname.style.border='none';

    }else{
    
        // console.log('fail')
        formData.uname.style.border='4px solid red';
        formData.passwrd.style.border='4px solid red';
        formData.loginSubmit.disabled=true;
    }
}
function validateForm1(){
    let formData = document.forms[0];
    let Password = formData.passwrd.value;
    if(Password.length>4)
    {
        console.log('Success');
        formData.passwrd.style.border='4px solid green';
    }else{
        formData.passwrd.style.border='4px solid blue';
    }
}