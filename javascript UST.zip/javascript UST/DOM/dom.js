let pElement=document.getElementById("demo");
console.log(pElement);
pElement.textContent="This i snew p tag";


let divelements = document.getElementsByClassName('blue');
console.log(divelements);

let pElements = document.getElementsByTagName('p');
console.log(pElements)

let nameElements=document.getElementsByName('helement');
console.log(nameElements);

let demoElement=document.querySelector('#demo');
console.log(demoElement);

let blueClassElements=document.querySelectorAll('.blue');
console.log(blueClassElements);

let buttonElement=document.createElement('button');
buttonElement.textContent="click Me";
console.log(buttonElement);
document.body.appendChild(buttonElement);

let buttonElement5 = document.createElement('button');
buttonElement5.textContent='ashwini';
document.body.appendChild(buttonElement5);

let spanEle = document.getElementById('spanid');
spanEle.style.color='blue';

let buttonElement1=document.getElementById('buttonEle');
// buttonElement1.className='add';
buttonElement1.classList='add add1';

let pElementData = document.getElementById('demo1');
// pElementData.style.color = 'blue';
pElementData.className= 'blue';/*it access the css class and apply*/
pElementData.classList='blue fonts';



