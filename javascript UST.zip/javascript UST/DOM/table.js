document.getElementById('tableid').innerHTML=
                `<table>
                <tr>
                 <td>Name</td>
                 <td>Age</td>
                </tr>
                <tr>
                        <td>John</td>
                        <td>10</td>
                       </tr>
                       <tr>
                            <td>Mike</td>
                            <td>20</td>
                           </tr>
            </table>`;

// let tableElement=document.createElement('table');
// tr1=document.createElement('tr');
// trd1=document.createElement('td');
// trd1.textContent='Name';
// trd2=document.createElement('td');
// trd2.textContent='Age';
// tr1.appendChild(trd1);
// tr1.appendChild(trd2);
// let a=tableElement.appendChild(tr1);
// console.log(a)

// tr11=document.createElement('tr');
// trd11=document.createElement('td');
// trd11.textContent='Name';
// trd22=document.createElement('td');
// trd22.textContent='Age';
// tr11.appendChild(trd11);
// tr11.appendChild(trd22);

// tableElement.appendChild(tr11);

// let buttonElement=document.createElement('button');
// buttonElement.textContent="click Me";
// console.log(buttonElement);
// document.body.appendChild(buttonElement);










