function sayHello(){
    alert('Hello');
}


let buttonElement =document.getElementById('clickButton');
// buttonElement.textContent="click Me";

buttonElement.onclick = function(){
    alert('hiiiiiiiiiii');
}

let buttonElement1=document.createElement('button');/*it is used to create button directly in javvascript*/
buttonElement1.textContent="click Me";
// console.log(buttonElement1);
document.body.appendChild(buttonElement1);

buttonElement1.onclick=function(){
    alert('Ashwini');
}

function createPElement(){
    let pElementData=document.createElement('p');
    pElementData.textContent="This is P element";
    document.body.appendChild(pElementData);
}

function createPara(){
    let pElementData11=document.createElement('p');
    pElementData11.textContent="This is Pp element";
    document.body.appendChild(pElementData11);
}


let alertElement = document.getElementById('alertHi')

alertElement.addEventListener("click",function(){/*clcik is an action case Insenstive*/
    alert("Good Evening");
});

//to get inpuuut element below it
let h1Element=document.createElement('wah');
function showText(){
    let inputElement = document.getElementById('showData');
    console.log(inputElement.value);//to get in console
    // inputElement.nodeValue;
    // let h1Element=document.createElement('wah');
    h1Element.textContent = inputElement.value;
    document.body.appendChild(h1Element);
}
