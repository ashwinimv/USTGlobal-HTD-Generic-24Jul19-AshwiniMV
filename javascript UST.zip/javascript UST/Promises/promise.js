let resultData = new Promise(function(resolve,reject){
    if(10>10){
        reject('Failes'); //if we comment the reject and resolve then it go pending state;
    }else{
        resolve('Success');
    }
})

resultData.then((data)=>{
    console.log('Then block ='+data);
}).catch((error)=>{
    console.log('catch block='+error);
});



let employeeData = new Promise(function(resolve,reject){
    const employee = [
        {
            name : 'Shahrukh',
            age : 60
        },
        {
            name : 'sundari',
            age:45
        },
        {
            name : 'Akshay',
            age : 50
        }
    ];
    if(10>10){
        reject('Failes'); //if we comment the reject and resolve then it go pending state;
    }else{
        resolve(employee);
    }
});

employeeData.then((data)=>{
    //console.log('Employee Data='+data);     //if i use concatination it show objects
    // console.log('Employee Data=',data);
    return data;
}).catch((error)=>{
    console.log('catch block='+error);
}).then(function(data1){
    console.log("This is block 2",data1);
});
