function sum(a,b){
    function addSum(){
        return a+b;
    }
    return addSum;
}

var addFun = sum(10,20);
var total = addFun();
console.log("total" +total);

console.log("============")

console.log(window);
console.log(this);
console.log(this===window);
console.log("*******");
var name="Rakshith";
console.log(window.name);
console.log(this.name)

var person = {

            name : 'Dulquer salman',
            age : 30,
            getName : function(){
                console.log("getMethod"+this)
                console.log(window);/*inside a method window and this isdifferent*/
                console.log("//////");
                getData();
                function getData(){
                    // console.log(this);
                    console.log("get data Method"+this)
                    console.log("get data Method"+this.name)/*this is window*/
                    
                }
                return this.name;/*whenever method is invoked using object reference object work for object*/
            }

}
// console.log('555555');
var hero = person.getName();
console.log("Name="+hero)

console.log("****************")

for(var i=0;i<5;i++){
    console.log(i);/*i belongs to function scope*/
}
console.log("value of i="+i)/*not showing means i is not in block scope because it is hoisted*/

/*for(let j=0;j<5;j++){
    console.log(j);
}
console.log("value of j="+j)*/

console.log("***********")

var hobbies = ['dancing','singing','cricket'];
console.log('Hobbies '+hobbies)

var hobbies = ['hiii'];
console.log('Hobbies '+hobbies)

hobbies = ['singing'];
 console.log("------------")

 let fruits = ['orange','banana'];
 console.log("fruits="+fruits);
//  let fruits = ['jackfruit'];/*in let redeclare is not possible reintialize is not possible*/
fruits = ['jackfruit'];
 console.log("fruits="+fruits);

 console.log("------------");

 const vegetables = ['carrot','raddish'];
 console.log("vegetables="+vegetables);
//  const vegetables = ['tomato'];/*redeclare not possible*/
// vegetables = ['tomato'];/* reinitialize not possible*/

vegetables[0]=['potato','brinjal']; /*modify is possible*/
 console.log("vegetables="+vegetables);



