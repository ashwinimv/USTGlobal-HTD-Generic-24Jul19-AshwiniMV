var person={
        name:'Ashwini',
        age:21,
        coloe:'white'
}
console.log(person);
console.log("***************");

person.name="kajol";
console.log(person);

var person1=person;
console.log(person1);

person1.name="mike";
console.log(person);
console.log(person1);
