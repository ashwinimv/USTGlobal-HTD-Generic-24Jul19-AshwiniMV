var msg="hello";
console.log(msg)

msg=msg+'world';

console.log(msg)
var msg1=msg;
console.log(msg1)
msg="hi";
console.log(msg);
console.log(msg1);