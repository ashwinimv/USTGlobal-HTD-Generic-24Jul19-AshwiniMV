var todaysDate=new Date();
console.log(todaysDate);
console.log("************");
var month=todaysDate.getMonth();
console.log(month)

console.log("//////////////////");


// var date=new Date();

var date=new Date(2018,11,24,10,33,30,0);
console.log("date==="+date);

var date1=new Date("October 13,2014 11:13:00");
console.log(date1);

console.log("****************")

var date3=new Date(0);
console.log(date3);

console.log("--------------------")

var months=['jan','feb','march','april','may','june','july','aug','sep','octo','nov','dec'];
 console.log("month="+months[todaysDate.getMonth()]);

 var days=['sun','mon','tue','wed','thu','fri','sat','sun'];
 console.log("Day="+days[todaysDate.getDay()]);
 console.log("Date="+todaysDate.getDate());



 
 console.log(Math.PI);
console.log(Math.floor(4.5))
console.log(Math.ceil(4.5))
console.log(Math.round(4.2))
console.log(Math.round(4.5))
console.log(Math.random(4,5))
console.log(Math.pow(4,5))
console.log("00000000000000000000")

var q=Math.floor((Math.random()*100)+1)/*in math floor will give the lower value*/
console.log(q)
console.log(Math.ceil(Math.random()*100))/*in ceil it will give the higher value*/




