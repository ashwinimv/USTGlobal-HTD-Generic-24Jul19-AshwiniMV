let employeeJSON = {

            name : 'guldu',
            age : 25,
            hobbies : ['dance','sing']

}


console.log(`My name is ${employeeJSON.name}`); //back tick is used is called stringinterpolation
console.log(employeeJSON);
let jsonObject = JSON.stringify(employeeJSON);
console.log(jsonObject);
let jsobject = JSON.parse(jsonObject);
console.log(jsobject)