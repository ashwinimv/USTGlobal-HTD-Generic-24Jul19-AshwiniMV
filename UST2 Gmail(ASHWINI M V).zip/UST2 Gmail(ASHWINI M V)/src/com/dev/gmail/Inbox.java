package com.dev.gmail;

public class Inbox {
	private int message_id;
	private int user_id;
	private String message;
	public int getMessage_id() {
		return message_id;
	}
	public void setMessage_id(int message_id) {
		this.message_id = message_id;
	}
	public int getUser_id() {
		return user_id;
	}
	@Override
	public String toString() {
		return "Inbox [message_id=" + message_id + ", user_id=" + user_id + ", message=" + message + "]";
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

}
