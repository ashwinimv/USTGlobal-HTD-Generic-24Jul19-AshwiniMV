package com.dev.gmail;

import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;

import javax.swing.text.DefaultEditorKit.InsertBreakAction;

public class GmailImplementation implements GmailInterface {

	static HashMap<String,Account> hm = new HashMap<String,Account>();
	static HashMap<String,Inbox>  hm1 =new  HashMap<String,Inbox>();


	
	@Override
	public Account insert(String k, Account a) {
		if(a!=null) {
			hm.put(k, a);
			Account b = hm.put(k, a);
			if(b!=null) {
				return a;
			}
		}
		return null;
	}
	@Override
	public Inbox addInbox(String k1, Inbox i) {
		if(i!=null) {
			hm1.put(k1, i);
			Inbox b1=hm1.put(k1, i);
			if(b1!=null) {
				return i;
			}
		}
		return null;
	}
	@Override
	public void display() {
		System.out.println(hm);
		
	}
	
	

	public Account insert1(String email,String password) {
		Account a1 = new Account();
		a1.setEmail(email);
		a1.setPassword(password);
		
		hm.put(email, a1);
		hm.put(password, a1);
		
        return a1;
	}

	public Inbox message1(String message) {
		Inbox i = new Inbox();
		i.setMessage(message);
		return i;
		 
	}
	public static void main(String[] args) {

		GmailImplementation mm = new GmailImplementation();
		Scanner sc=new Scanner(System.in);


		Account a1 = new Account();
		Account a =new Account();
		a.setUser_id(1);
		a.setUser_name("ashwini");
		a.setPassword("1234");
		a.setEmail("ashwinimv@gmail.com");

		Account c = mm.insert("1", a);
		System.out.println("Account Details"+c);
		System.out.println("--------------");

		Inbox i1 = new Inbox();
		i1.setMessage("hi");
		i1.setUser_id(1);
		i1.setMessage_id(11);

		Inbox x = mm.addInbox("2", i1);
		System.out.println("Inbox Details"+x);

		Set<String> keys = hm.keySet();
		/*for(Integer key:keys) {
			System.out.println("Keys :"+key);
		}*/


		System.out.println("------------------");
		int value;
		System.out.println("enter a value");
		value=sc.nextInt();

		switch(value) {
		case 1: System.out.println("Login");
		        System.out.println("Enter email and password");
		        String email1 = sc.next();
		        String password1 = sc.next();

		        mm.insert1(email1,password1);

		        /*System.out.println("Email"+a.getEmail());
		         System.out.println("Password"+a.getPassword());*/
		        System.out.println("-----------------");
		        System.out.println("Press a to  compose");
		        System.out.println("-------------------");
		        System.out.println("press b to show inox");
		        String ch="A";
		        ch=sc.next();
		        String ch2=ch;
		        if(ch2==ch) {
			      System.out.println(a.getEmail());
			      String message = sc.next();
			      mm.message1(message);
			      //System.out.println(message);
			     
		        }

		         String ch1="B";
		         ch1=sc.next();
		         String ch3=ch1;
		         if(ch3==ch1) {
			         System.out.println(i1.getMessage());
			        
			          
		           }
                  break;

		case 2:System.out.println("register");
			   System.out.println("enter email and password to create an account");
		       String email = sc.next();
		       String password = sc.next();
               mm.insert1(email,password);
		       System.out.println("your account is created");
     	         //mm.insert("2", a1);
		        mm.display();
               break;


		default:System.out.println("invalid");


		}
		


	}
	
	

	

}
