package com.dev.gmail;

public interface GmailInterface {
	
	
	public Account insert(String k,Account a);
	public Inbox addInbox(String k1,Inbox i);
	public void display();

}
