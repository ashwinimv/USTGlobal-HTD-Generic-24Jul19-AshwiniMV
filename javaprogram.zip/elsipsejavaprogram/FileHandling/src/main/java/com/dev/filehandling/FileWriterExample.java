package com.dev.filehandling;
import java.io.FileWriter;
import java.io.IOException;

public class FileWriterExample {
	public static void main(String args[]) throws IOException{    
//        try{    
//          FileWriter fw=new FileWriter("F:\\testout.txt");    
//          fw.write("Welcome to javaTpoint.");    
//          fw.close();    
//         }catch(Exception e){System.out.println(e);}    
//         System.out.println("Success...");  
		
		FileWriter fw=new FileWriter("F:\\testout1.txt");    
        fw.write("Welcome to javaTpoint.");    
        fw.close();  
    }    

}
