package com.dev.typecasting;

import java.util.Scanner;

public class One {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i = 10;
		byte b = (byte) i;
		int r =b;
		System.out.println(r);
		
		int b1 = 98;
		char x = (char) b1;
		System.out.println(x);
		
		int y;
		System.out.println("enter an integer");
		y=sc.nextInt();
		System.out.println(y);
		
		

	}

}
