package com.dev.methods;

public class MethodOverloadingOperations {
	
public String addition(String  a ,String  b) {
		
		System.out.println("Addition operation of 2 parameters = "+(a+b));
		return a+b;
	}

	public int addition(int a ,int b) {
		
		System.out.println("Addition operation of 2 parameters = "+(a+b));
		return a+b;
	}
	 public int addition(int a ,int b,int c) {
			
			System.out.println("Addition operation of 3 parameters = "+(a+b+c));
			return a+b+c;
		}
      public int addition(int a ,int b,int c,int d) {
		
		System.out.println("Addition operation of 4 parameters = "+(a+b+c+d));
		return a+b+c+d;
	}
	
	public float substraction(float c ,float d) {
		System.out.println("Substraction operation of 2 parameters = "+(c-d));
		return c-d;
	}
	public float substraction(float c ,float d,float e) {
		System.out.println("Substraction operation of 3 parameters = "+(c-d-e));
		return c-d-e;
	}
	public float substraction(float c ,float d,float e,float f) {
		System.out.println("Substraction operation of 4 parameters = "+(c-d-e-f));
		return c-d-e-f;
	}
	public double multiplication(double j,double k) {
		System.out.println("Multiplication operation of 2 parameters = "+(j*k));
		return j*k;
     }
	public double multiplication(double j,double k,double l) {
		System.out.println("Multiplication operation of 3 parameters = "+(j*k*l));
		return j*k*l;
     }
	
	public double multiplication(double j,double k,double l,double h) {
		System.out.println("Multiplication operation of 4 = "+(j*k*l*h));
		return j*k*l;
     }
	public double division(double m,double n) {
		System.out.println("Division operation of 2 parameters = "+(m/n));
		return m/n;
	}
	public double division(double m,double n,double k) {
		System.out.println("Division operation  of 3 parameters = "+(m/n/k));
		return m/n/k;
	}
	public double division(double m,double n,double k,double j) {
		System.out.println("Division operation of 4 parameters = "+(m/n/k/j));
		return m/n/k/j;
	}
	
	
	
	

	public static void main(String[] args) {
		MethodOverloadingOperations m = new MethodOverloadingOperations();
		m.addition("a", "b");
		m.addition(5,6);
		m.addition(5,6,7);
		m.addition(5,6,7,8);
		
		m.substraction(5f, 6f);
		m.substraction(5f, 6f,10f);
		m.substraction(5f, 6f,10f,20f);
		
		m.multiplication(5.0, 6.0);
		m.multiplication(5.0, 6.0,7.0);
		m.multiplication(5.0, 6.0,7.0,8.0);
		
		m.division(30.0,5.0);
		m.division(30.0,5.0,20.0);
		m.division(30.0,5.0,15.0,45.0);
		
		
		
	
		


	}

}
