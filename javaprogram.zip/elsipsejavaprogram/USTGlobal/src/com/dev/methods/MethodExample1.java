package com.dev.methods;

public class MethodExample1 {
	public static void main(String args[]) {
		MethodExample me = new MethodExample(); //non-static
		int area1 = MethodExample.calcArea(11);
		System.out.println(area1);
		int area2=me.areaRect(5, 7);
		System.out.println("area of rectangle = "+area2);

	}


}
