package com.dev.methods;

public class MethodOverloading {
	
	static MethodOverloading m = new MethodOverloading(); //we can write object in main method without using static keyword
	
	public void print() {
		System.out.println("This is print method with no-arg");
	}
	public int  print(int i) {
		System.out.println("This is print method with int arg");
		return 1;
	}
	static String print (String str) {
		System.out.println("this print method with string");
		return "a";
	}
	
	

	public static void main(String[] args) {
		//MethodOverloading m = new MethodOverloading();
		m.print();
		m.print(5);
		m.print();
	

	}

}
