package com.dev.methods;

public class MethodststicExample {
	public static int j = 0;
	
	//static MethodststicExample me = new MethodststicExample();

	public static void main(String[] args) {
		MethodststicExample me = new MethodststicExample();
		j = calcArea(6);
		System.out.println("area of squar = "+j);
		int area1 = me.areaRect(2, 4);
		System.out.println("area of rectangle = "+area1);
		

	}
	public static int calcArea(int side) {
		int t= side*side;
	//	int n  = me.areaRect(4, 8);
		//System.out.println("method = "+n);
		return t;
	}
	public int areaRect(int len,int width) {
		j = len*width;
		return j;
	}
}
