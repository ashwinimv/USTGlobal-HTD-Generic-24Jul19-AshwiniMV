package com.dev.methods;


public final class Test extends Demo1{
	/*static void print() {  //cannot override the final method
		System.out.println("method");
	}*/

	public static void main(String[] args) {
		//Demo1.print();

	}

}
