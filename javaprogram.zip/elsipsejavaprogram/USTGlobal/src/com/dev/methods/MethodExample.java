package com.dev.methods;

public class MethodExample {
	static int j = 0;
	static char ch = 'a';
	

	public static void main(String[] args) {
		MethodExample me = new MethodExample();
		int area = calcArea(5);
		System.out.println(area);
		int area1 = me.areaRect(2, 4);
		System.out.println("area of rectangle = "+area1);



	}

	public static int  calcArea(int side) {
		int area = side*side;
		return area;

	}
	public int areaRect(int len,int width) {
		int area = len*width;
		return area;
	}
}
