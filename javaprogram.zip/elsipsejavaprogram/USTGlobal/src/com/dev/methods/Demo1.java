package com.dev.methods;

import com.dev.encapsulation.Dog;

public  class Demo1 {
/*Dog d = new Dog();//import from encapsulation
com.dev.constructor.Dog d1 = new  com.dev.constructor.Dog(); //fully qualified name
*/
final static int I=9;//final variable should be declared in block letters

final static void print() {
	System.out.println("Final method");
}

public static void main(String[] args) {
	System.out.println(I);//show error because it if dont make i as static
	print();
//	i=5;//reinitialize is not possible;
	
}

}
