package com.dev.prac;

public interface EmpInt {
  public Employees addEmp(String k,Employees e);
  public Employees removeEmp(String s);
  

}
