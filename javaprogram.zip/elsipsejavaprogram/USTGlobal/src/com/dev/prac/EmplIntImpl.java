package com.dev.prac;

import java.util.HashMap;


public class EmplIntImpl implements EmpInt{
	
	 HashMap<String,Employees> hm = new HashMap<String,Employees>(); 
  

	@Override
	public Employees addEmp(String k, Employees e) {
		if(e!=null) {
			hm.put(k, e);
			Employees b = hm.put(k,e);
			if(b!=null) {
				return b;
				
			}
			
		}
		return null;
	}
	
	
	public static void main(String[] args) {
		   EmplIntImpl ee = new EmplIntImpl();	
		   
			Employees e = new Employees();
			e.setEmail("assss");
			e.setId(1);
			e.setName("jdjjd");
			e.setPassword("55555");
			Employees e1 = new Employees();
			e1.setEmail("assss");
			e1.setId(1);
			e1.setName("jdjjd");
			e1.setPassword("55555");
			
			Employees b = ee.addEmp("1", e);
			System.out.println(b);
			
			/*Employees b1 = ee.removeEmp("1");
			System.out.println(b1);*/
			
			
			
			
		
	}

	@Override
	public Employees removeEmp(String s) {
		Employees e=hm.remove(s);
		return e;
		//return null;
	}
	
	

}
