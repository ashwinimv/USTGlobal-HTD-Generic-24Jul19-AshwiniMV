package com.dev.prac;

import java.util.HashMap;

public class EmpData {
	public static void main(String[] args) {
		HashMap<String,Employees> hm = new HashMap<String,Employees>(); 
	   EmplIntImpl ee = new EmplIntImpl();		
		Employees e = new Employees();
		e.setEmail("assss");
		e.setId(1);
		e.setName("jdjjd");
		e.setPassword("55555");
		
		hm.put("10",e);
		System.out.println(hm);
		
	}

}
