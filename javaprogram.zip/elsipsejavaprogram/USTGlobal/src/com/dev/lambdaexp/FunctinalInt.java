package com.dev.lambdaexp;
@FunctionalInterface
public interface FunctinalInt {
	public void show();
	

}
