package com.dev.lambdaexp;

@FunctionalInterface
public interface FunctInt2 {
	public void printVal(int i);

}
