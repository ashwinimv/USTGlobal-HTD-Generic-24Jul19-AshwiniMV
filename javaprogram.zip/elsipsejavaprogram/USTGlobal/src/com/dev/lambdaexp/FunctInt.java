package com.dev.lambdaexp;

@FunctionalInterface
public interface FunctInt {
	public void printVal();

}
