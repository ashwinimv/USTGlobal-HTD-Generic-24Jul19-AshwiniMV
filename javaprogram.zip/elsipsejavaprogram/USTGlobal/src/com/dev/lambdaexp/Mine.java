package com.dev.lambdaexp;

public class Mine {
	
	public static void main(String[] args) {
		FunctinalInt f =()->{
			for(int i=1;i<=10;i++) {
				System.out.println("i ="+i);
			}
			
		};
		f.show();
		
		FunctinalInt f1 =()->{
			try {
				int i=0/10;
				System.out.println(i);
				
			}catch(Exception e) {
				System.out.println("Exception");
				
				
			}
		};
		f1.show();
		
		FunctinalInt f2 = ()->
		System.out.println("hii");
		
		f2.show();
		
	}

}
