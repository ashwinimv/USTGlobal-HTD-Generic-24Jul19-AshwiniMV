package com.dev.colletions;
import java.util.HashMap;
import java.util.HashSet;

import com.dev.encapsulation.Dog;
import com.dev.encapsulation.Employee;

public class C3{

	public static void main(String[] args) {
		HashMap<String ,Dog> hs= new HashMap<String ,Dog>();
		Dog d = new Dog();
		d.setAge(1);
		d.setBreed("D M");
		d.setName("shiro");
		d.setColor("black");
		
		Dog d1 = new Dog();
		d1.setAge(2);
		d1.setBreed("Dalmation");
		d1.setName("Ronnie");
		d1.setColor("black&white");
		
		Dog d2 = new Dog();
		d2.setAge(3);
		d2.setBreed("Dalmation");
		d2.setName("Nikkie");
		d2.setColor("black&white");
		
		//hs.put("1", d);//if we don't write this,if we run line 30 it show null
		//hs.put("1", null);//it gives output null
		//Dog b = hs.put("1", d1); //return type is whatever type we are using;put return the type object,if we write d1 also it gives output of d only
		//System.out.println(b);
		
		
		hs.put("1", d);
		hs.put("2", d1);
		hs.put("3", d2);
		System.out.println(hs);
		
		Dog f=hs.remove("2");//return type remove is object
		System.out.println(f);
		System.out.println(hs);
		
		System.out.println("conatinsKey():"+hs.containsKey("1"));
		System.out.println("conatinsKey():"+hs.containsKey("2"));
		System.out.println("conatinsValue():"+hs.containsValue(d));
		System.out.println("conatinsValue():"+hs.containsValue(d1));
		
		
		
		
		

	}

}
