package com.dev.colletions;

//import com.dev.encapsulation.Employee;

public class Employee implements Comparable<Employee> {

	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id + ", email=" + email + ", password=" + "******" + "]";
	}


	private String name;
	private int id;
	private String email;
	private String password;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public static void main(String[] args) {
		
	}
	@Override
	public int compareTo(Employee e) {
		// TODO Auto-generated method stub
		return (this.id- e.id); //obj1.compareTo - obj2 here obj1 is invoking compareTo which means this.id and obj2 is e.id
	}
}
