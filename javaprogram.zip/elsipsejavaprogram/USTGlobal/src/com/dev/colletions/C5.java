package com.dev.colletions;

import java.util.TreeSet;

import com.dev.encapsulation.Dog;
import com.dev.encapsulation.Employee;

public class C5 {

	public static void main(String[] args) {
		TreeSet<Employee> ts = new TreeSet<Employee>();
		Employee e = new Employee();
		e.setName("Ashwini");
		e.setId(10);
		e.setEmail("ashwini@gmail.com");
		e.setPassword("1234");
		
		Employee e1 = new Employee();
		e1.setName("deepika");
		e1.setId(2);
		e1.setEmail("deepika@gmail.com");
		e1.setPassword("123456");
		
		Employee e2 = new Employee();
		e2.setName("sarika");
		e2.setId(3);
		e2.setEmail("sarika@gmail.com");
		e2.setPassword("12345678");
		
		ts.add(e);
		ts.add(e1);
		ts.add(e2);
		
		System.out.println(ts); //output will sorted according to the id in ascending order
		
		

	}

}
