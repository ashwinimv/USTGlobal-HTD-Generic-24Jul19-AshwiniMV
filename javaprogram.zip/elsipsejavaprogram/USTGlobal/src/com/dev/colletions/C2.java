package com.dev.colletions;
import java.util.HashSet;

import com.dev.encapsulation.Employee;

public class C2 {

	public static void main(String[] args) {
		HashSet<Employee> hs= new HashSet<Employee>();
		
		Employee e = new Employee();
		e.setName("Ashwini");
		e.setId(1);
		e.setEmail("ashwini@gmail.com");
		e.setPassword("1234");
		
		Employee e1 = new Employee();
		e1.setName("deepika");
		e1.setId(2);
		e1.setEmail("deepika@gmail.com");
		e1.setPassword("123456");
		
		Employee e2 = new Employee();
		e2.setName("sarika");
		e2.setId(3);
		e2.setEmail("sarika@gmail.com");
		e2.setPassword("12345678");
		
		e.setEmail("ashwinimv1234@gmail.com");
		e1.setEmail("deepika1234@gmail.com");
		e2.setEmail("sarika1234@gmail.com");
		
		boolean b = hs.add(e);
		boolean b1=hs.add(e1);
		boolean b3=hs.add(e2);
		System.out.println("add():"+b+" "+b1+" "+b3);
		System.out.println(hs);
		
		boolean b2 = hs.remove(e);
		System.out.println("remove()"+b2);
		System.out.println(hs);
		
		System.out.println("contains():"+hs.contains(e));
		hs.clear();
		System.out.println("size():"+hs.size());
		

	}

}
