package com.dev.colletions;

import java.util.HashSet;
import java.util.Iterator;

import com.dev.encapsulation.Dog;

public class C1 {
	public static void main(String[] args) {
		HashSet<Dog> hs = new HashSet<Dog>();
		Dog d = new Dog();
		d.setAge(1);
		d.setBreed("D M");
		d.setName("shiro");
		d.setColor("black");
		
		Dog d1 = new Dog();
		d1.setAge(2);
		d1.setBreed("Dalmation");
		d1.setName("Ronnie");
		d1.setColor("black&white");
		
		Dog d2 = new Dog();
		d2.setAge(3);
		d2.setBreed("Dalmation");
		d2.setName("Nikkie");
		d2.setColor("black&white");
		
		d.setAge(2);
		d1.setAge(3);
		d2.setAge(4);
		
		
		boolean b=hs.add(d);
		boolean b1=hs.add(d1);
		boolean b3=hs.add(d2);
		System.out.println("output of add():" +b+" "+b1);
		System.out.println("jhfg"+hs);
		
		for (Dog dog : hs) {
			System.out.println(dog);
		}
		
		
		System.out.println(hs);
		
		System.out.println("Size of HashSet hs:"+hs.size()); //before remove method it is 3
		
		boolean b2=hs.remove(d);
		System.out.println("output of remove():"+b2);
		System.out.println(hs);
		
		//boolean b4=hs.contains(d);
		System.out.println("output of contains():"+hs.contains(d));//output is false because d is removed
		
		hs.clear();
		System.out.println("Size of HashSet hs:"+hs.size());//after remove method it is 2 without writing hs.clear(),if we write hs.clear it show 0

	}
}
