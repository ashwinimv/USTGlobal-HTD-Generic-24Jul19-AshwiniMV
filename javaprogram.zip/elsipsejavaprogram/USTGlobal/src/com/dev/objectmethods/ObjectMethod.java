package com.dev.objectmethods;

public class ObjectMethod  {
	
	public static void main(String[] args) {
		Dog d1 = new Dog();
		Dog d2 = new Dog();
		
		System.out.println(d1.getClass());
		System.out.println(d2.getClass());
	}

}
