package com.dev.objectmethods;

public class Demo {   //see the extended part strings test.java;
                                   
	public static int i=10;
	public static String str = "static string";
	
	public static void print() {
		System.out.println("static print method");
	}
	
	public static void name() {
		System.out.println("sttaic named method");
	}
}
