package com.dev.abstraction;

public interface InterfaceA extends InterfaceOne{

}
