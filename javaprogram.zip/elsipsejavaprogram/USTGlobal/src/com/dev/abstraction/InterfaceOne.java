package com.dev.abstraction;

public interface InterfaceOne {
	void display(); //in interface by default it will be abstract method only
	
	public  static void print() {
		System.out.println("a");
	}
		 default void print1() {
			System.out.println("b");
		}
		
	

}
