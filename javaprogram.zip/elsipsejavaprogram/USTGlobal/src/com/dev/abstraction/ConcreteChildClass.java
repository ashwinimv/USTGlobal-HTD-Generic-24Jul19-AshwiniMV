package com.dev.abstraction;

public class ConcreteChildClass extends ChildAbstract {

	public static void main(String[] args) {
		ConcreteChildClass c = new ConcreteChildClass();
		c.parent();
		c.show();
		c.print();
		
		

	}

	@Override
	void print() {
		System.out.println("ashwini");
		
	}

}
