package com.dev.abstraction;

public   class ChildAbstract extends ParentAbstract{
	
	

	public static void main(String[] args) {
		//ChildAbstract c = new ChildAbstract();
		//c.parent();
		//c.print();

	}

	@Override
	void parent() {
		System.out.println("parennt ");
		
	}

	@Override
	void print() {
		System.out.println("print");
		
	}

		
	}
	

