package com.dev.abstraction;

public class ClassTwo implements InterfaceOne,InterfaceTwo{

	public static void main(String[] args) {
		
		InterfaceOne.print(); //static directly we can use it.
		ClassTwo c = new ClassTwo();
		c.display();
		c.print1(); //default we have to create an object of a class.

	}

	@Override
	public void display() {
		System.out.println("display the method of interface");
		
	}

	@Override
	public void display1() {
		// TODO Auto-generated method stub
		
	}

}
