package com.dev.abstraction;

public class ConcreteClass extends ParentAbstract{

	public static void main(String[] args) {
		ConcreteClass p = new ConcreteClass();
		p.show();
		p.parent();
		p.print();
		
		

	}

	@Override
	void parent() {
	//	System.out.println("It is concrete class");
		
	}

	@Override
	void print() {
		// TODO Auto-generated method stub
		
	}

}
