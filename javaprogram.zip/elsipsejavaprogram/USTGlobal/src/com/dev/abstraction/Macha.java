package com.dev.abstraction;

public class Macha {
	
	public static int i =2; // when we want to invoke in some other package,if we dont give access specifier it give error when we trying to access in some other package.
	public static String str = "abc";
	
	public  void show() {
		System.out.println("show()");
	}

	public static void main(String[] args) {
		

	}

}
