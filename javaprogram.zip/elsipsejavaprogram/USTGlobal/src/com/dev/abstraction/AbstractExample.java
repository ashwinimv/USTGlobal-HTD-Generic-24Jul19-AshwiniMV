package com.dev.abstraction;

public abstract class AbstractExample {
	abstract void display();  //when we are using abstract method ,we have make class has abstract class using abstract keyword otherwise it show error.
	//abstract void print();
	public AbstractExample() { //we can have constructor for abstract class
		System.out.println("const of abstractExample");
	}
	public static void show() { //concrete method
		System.out.println("concrete method of abstract class");
	}

	public static void main(String[] args) {
		
		show();
		
		

	}

}
