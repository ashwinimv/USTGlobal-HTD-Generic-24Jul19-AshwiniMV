package com.dev.abstraction;

public interface InterfaceB extends InterfaceA,InterfaceTwo {

}
