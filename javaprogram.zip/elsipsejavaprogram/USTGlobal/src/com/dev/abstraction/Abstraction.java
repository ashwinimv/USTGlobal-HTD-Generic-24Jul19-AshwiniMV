package com.dev.abstraction;

public  class Abstraction extends AbstractExample {
	//AbstractExample ae = new AbstractExample(); //AbstractExample is an abstract class we can't create an object.

	
	public Abstraction() { //constructor
		System.out.println("Cost of Abstraction class");
	}
	@Override
	void display() {
	    System.out.println("This is the implemented abstract method");
		
	}
	public static void main(String[] args) {
		
		Abstraction a = new Abstraction();
		//a.display();
		a.show();
	}

}
