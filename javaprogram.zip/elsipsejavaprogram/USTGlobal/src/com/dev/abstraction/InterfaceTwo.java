package com.dev.abstraction;

@FunctionalInterface
public interface InterfaceTwo  {
	void display1();
	
	public int i =2; // we have to initialize otherwise it show error;
	
	static  void print() {
		System.out.println("a");
	}

}
