package com.dev.abstraction;

public abstract class ParentAbstract {
	
	abstract void parent();
	abstract void print();
	
	
	public void show() { //concrete method
		System.out.println("concrete method of abstract class");
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
