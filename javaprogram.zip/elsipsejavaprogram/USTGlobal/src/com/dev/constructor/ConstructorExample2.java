package com.dev.constructor;
//constructor overloading;
public class ConstructorExample2 {
	

	public ConstructorExample2() {
		System.out.println("this constructor is no argument constructor");
	}
	public ConstructorExample2(int i) {
		System.out.println("this const is with int argument");
	}
	public ConstructorExample2(String s) {
		System.out.println("this const is with string argument");
	}
	public ConstructorExample2(String s,int j) {
		System.out.println("this const is with string and int argument");
	}
	public ConstructorExample2(int s,String j) {
		System.out.println("this const is with int  and string  argument");
	}

	public static void main(String[] args) {
		
		ConstructorExample2 c = new ConstructorExample2();
		ConstructorExample2 c1 = new ConstructorExample2(1);
		ConstructorExample2 c2 = new ConstructorExample2("j");
		ConstructorExample2 c3 = new ConstructorExample2("k",10);
		ConstructorExample2 c4 = new ConstructorExample2(1,"a");

	}

}
