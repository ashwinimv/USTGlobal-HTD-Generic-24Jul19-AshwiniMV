package com.dev.constructor;
import com.dev.methods.MethodststicExample;

public class Demo {

	public static void main(String[] args) {
		int i =  MethodststicExample.calcArea(10);
		System.out.println(i);
		System.out.println(MethodststicExample.j);

	}

}
