package com.dev.constructor;

public class ConstructorOverloading {
	
	public  ConstructorOverloading() {
		System.out.println("this constructor is no argument constructor" );
	}
	 
	public ConstructorOverloading(int i)
	{
		System.out.println("this const is with int argument = " +i);
	}

	public ConstructorOverloading(double f,int i) {
		System.out.println("this const is with double and int");
	}
	
	public ConstructorOverloading(String s,int k) {
		System.out.println("this const is with string and int");
	}
	public ConstructorOverloading(String s,int k,float h) {
		System.out.println("this const is with string and int and float");
	}
	public static void main(String[] args) {
		ConstructorOverloading ce = new ConstructorOverloading();
		System.out.println(ce);;
		ConstructorOverloading ce1 = new ConstructorOverloading(10);
		System.out.println(ce1);
		ConstructorOverloading ce2 = new ConstructorOverloading(1.5,10);
		System.out.println(ce2);
		ConstructorOverloading ce3 = new ConstructorOverloading("a",5);
		System.out.println(ce3);
		ConstructorOverloading ce4 = new ConstructorOverloading("A",25,12.5f);
		System.out.println(ce4);
		
		
	

	}

}
