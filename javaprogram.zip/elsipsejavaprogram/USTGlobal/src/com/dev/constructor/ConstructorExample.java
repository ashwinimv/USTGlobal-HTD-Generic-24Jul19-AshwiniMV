package com.dev.constructor;

public class ConstructorExample {
	public ConstructorExample(int i) {
		System.out.println("this is user defined constructor");
	}

	public ConstructorExample() {
		System.out.println("this constructor is no argument constructor");
	}
	public static void main(String[] args) {
		ConstructorExample c = new ConstructorExample(1);//if user creating a constructor need to pass parameter
		ConstructorExample c1 = new ConstructorExample();//no argument doesnot take argument.
		
	}

}
