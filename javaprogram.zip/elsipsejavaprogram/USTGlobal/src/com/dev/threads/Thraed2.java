package com.dev.threads;

public class Thraed2  extends Thread{ //when we have Thread run method is implemented

	@Override
	public void run() {
		System.out.println("T2 thread strated");
		   System.out.println("Thraed2 class prints the value of j");
		for(int j=1;j<=10;j++) {
			System.out.println("j ="+j);
		}
		
		
		
		System.out.println("T2 thread termintaed");
		
	}

}
