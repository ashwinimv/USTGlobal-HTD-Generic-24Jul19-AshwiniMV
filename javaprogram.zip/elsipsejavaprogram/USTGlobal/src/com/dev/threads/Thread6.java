package com.dev.threads;

public class Thread6 extends Thread{
	
	
	Printer p;
	
	public Thread6(Printer pref){
		p = pref;
		
	}
	
	
	@Override
	public void run() {
		try {
			Thread.currentThread().sleep(500);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		p.printVal(5, "Thread 5");
	}

}
