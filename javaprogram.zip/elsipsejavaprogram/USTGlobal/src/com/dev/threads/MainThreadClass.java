package com.dev.threads;

public class MainThreadClass {

	public static void main(String[] args) {
	    System.out.println("Main thread started");
	    System.out.println("MainThraed class prints the value of i");
	    
	    
	    //new T2().start();
	    
	    Thraed2 t2 =new Thraed2();
	    t2.setName("Thread T2");
	    t2.setPriority(1);
	    t2.start();
	    
	 
	    
	   
	     
	    
        Thread3 t3 =new Thread3();
	    Thread t =new Thread(t3);	   
	    t.start(); //or              //  new Thread(new T3()).start(); 
	    
	    t2.setPriority(10);
	    Thread.currentThread().setName("Main Thraed");
	    
	    
	    
	
	    
	    
	    for(int i=1;i<=10;i++) {
	    	System.out.println("i = "+i);
	    }
	    
	    System.out.println("Thread Name "+t2.getName());
	   
	    System.out.println("Current Thread"+Thread.currentThread().getName());
	    System.out.println("Thraed2 id:"+t2.getId()); // these id's are given by threadSchdeular for all 3
	    System.out.println("Thraed3 id:"+t.getId());
	    System.out.println("Main Thread id:"+Thread.currentThread().getId());
	    System.out.println("Thraed2 Priority "+t2.getPriority());
	    System.out.println("Thraed3 Priority "+t.getPriority());
	    System.out.println("Main Priority "+Thread.currentThread().getPriority());
	    System.out.println("Main thread terminated");

	}

}
