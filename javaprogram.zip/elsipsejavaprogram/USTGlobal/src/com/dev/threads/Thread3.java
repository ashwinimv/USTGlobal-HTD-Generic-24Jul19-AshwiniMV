package com.dev.threads;

public class Thread3 implements Runnable { //runnable only have single method run

	@Override
	public void run() {
		System.out.println("T3 is started");
		   System.out.println("Thraed3 class prints the value of k");
		for(int k=1;k<=10;k++) {
			System.out.println("k ="+k);
		}
		
		
		
		System.out.println("T3 is terminated");
		
	}
	
	

}
