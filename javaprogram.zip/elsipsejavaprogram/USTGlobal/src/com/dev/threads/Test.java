package com.dev.threads;

public class Test {

	public static void main(String[] args) {

		new Thraed2().start();

		for(int i=1;i<=100000;i++) {
			System.out.println("i = "+i);
		}
		
		for(int i=0;i<10;i++) {
			System.out.println("i =:"+i);
			
		}


		System.out.println("Main thread terminated");
	}

}
