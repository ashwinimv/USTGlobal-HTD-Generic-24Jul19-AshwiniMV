package com.dev.encapsulation;

public class StudentData {

	public static void main(String[] args) {
		Student s = new Student();
		s.setRegno(2019001);
		s.setName("ashwini");
		s.setEmail("ashwinimv@gmail.com");
		s.setPassword("1234");
		
		int regno = s.getRegno(); //because regno is integer type store in integer format;
		System.out.println("registration no = "+regno); //or
		System.out.println("registration no = "+s.getRegno());
		
		System.out.println("Name = "+s.getName());
		System.out.println("Name = "+s.getEmail());
		
	}

}
