package com.dev.encapsulation;

public class DogData {
public static void main(String[] args) {
	Dog d1 = new Dog();
	Dog d2 = new Dog();
	Dog d3 = new Dog();
	Dog d4 = new Dog();
	
	d1.setAge(1);
	d1.setBreed("Dober man");
	d1.setColor("black");
	d1.setName("shiro");
	
	d2.setAge(2);
	d2.setBreed("German Shepherd");
	d2.setName("Spike");
	d2.setColor("brown");
	
	d4.setAge(2);
	d4.setBreed("German Shepherd");
	d4.setName("Spike");
	d4.setColor("brown");
	
	d3.setAge(3);
	d3.setBreed("German Shepherd");
	d3.setColor("Black&Brown");
	d3.setName("Abby");
	
	Dog [] dogs = {d1,d2,d3,d4};
	
	for(int i=0;i<dogs.length;i++) {
		System.out.println("Age: "+dogs[i].getAge());
		System.out.println("name " +dogs[i].getName());
		System.out.println("breed : "+dogs[i].getBreed());
		System.out.println("color : "+dogs[i].getColor());
		System.out.println("***********************");
		//System.out.println(dogs[i]);
	}
	
	System.out.println(d2.equals(d4)); //it shows the false output
	System.out.println(d2.hashCode());
	System.out.println(d4.hashCode());
}
}
