package com.dev.encapsulation;

public class Pets {

	private String catname;
	private String dogname;
	private String parrot;
	
	public String getParrot() {
		return parrot;
	}
	public void setParrot(String parrot) {
		this.parrot = parrot;
	}
	public String getCatname() {
		return catname;
	}
	public void setCatname(String catname) {
		this.catname = catname;
	}
	public String getDogname() {
		return dogname;
	}
	public void setDogname(String dogname) {
		this.dogname = dogname;
	}

	
}
