package com.dev.encapsulation;

public class PetsData {

	public static void main(String[] args) {
		Pets p = new Pets();
		Pets p1 = new Pets();
		Pets p2 = new Pets();
		
		p.setCatname("chinnu");
		p.setDogname("bruno");
		p.setParrot("raja");
		
		p1.setCatname("gollu");
		p1.setDogname("raju");
		p1.setParrot("rani");
		
		p2.setCatname("kittu");
		p2.setDogname("spike");
		p2.setParrot("mollu");
		
		Pets [] pet = {p,p1,p2};
		for(int i=0;i<pet.length;i++) {
			System.out.println("cat name :"+pet[i].getCatname());
			System.out.println("dog name : "+pet[i].getDogname());
			System.out.println("parrot name : "+pet[i].getParrot());
			System.out.println("************");
		}
		
		
		

	}

}
