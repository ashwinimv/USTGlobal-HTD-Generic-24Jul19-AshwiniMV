package com.dev.encapsulation;

public class Student {
	private int regno;
	private String name;
	private String email;
	private String password;

	public int getRegno() {
		return regno;
	}

	public void setRegno(int regno) { //return type for setter  is always void.
		this.regno = regno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public static void main(String[] args) { //here password has set method not get method,because passowrd can only write only
		// TODO Auto-generated method stub

	}

}
