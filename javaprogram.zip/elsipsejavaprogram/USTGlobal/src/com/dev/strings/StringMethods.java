package com.dev.strings;

public class StringMethods {

	public static void main(String[] args) {
		String str = "some String";
		String a  = "some String";
		int length = str.length();
		System.out.println("output length = "+length);
		
		char[] ch = str.toCharArray();
		System.out.println("output tocharArray = "+ch[1]);
		
		char c = str.charAt(5);
		System.out.println("output charAt = "+c);
		
		//java.lang.String
		
		boolean b = str.equals(a);
		System.out.println("output equlas = "+b);
		
		boolean b1 = str.equalsIgnoreCase(a);
		System.out.println("output equlasIgnore = " +b1);
		
		boolean b2 = str.contains("som");
		System.out.println("output contains = " +b2);
		
		String g = str.replace('s', 'a');
		System.out.println("output replace('s','a') = " +g);
		
		int f = str.indexOf('S');
		System.out.println("output indexof = " +f);
		
		String s = str.toUpperCase();
		System.out.println("output uppercase = " +s);
		
		String h = str.toLowerCase();
		System.out.println("output lowercase = " +h);
		
		String b3 = str.substring(3);
		System.out.println("output of substrung = "+b3);
		
		String b4 = str.substring(3,7);
		System.out.println("output of substrung = "+b4);
		
		


	}

}
