package com.dev.strings;

public class StringMethods1 {

	public static void main(String[] args) {
		String str = "Hello_java";
		String a  = "Hello_Java";
		int length = str.length();
		System.out.println("output length = "+length);
		
		char[] ch = str.toCharArray();
		System.out.println("output tocharArray = "+ch[1]);
		
		char c = str.charAt(5);
		System.out.println("output charAt = "+c);
		
		//java.lang.String
		
		boolean b = str.equals(a);
		System.out.println("output equlas = "+b);
		
		boolean b1 = str.equalsIgnoreCase(a);
		System.out.println("output equlasIgnore = " +b1);

	}

}
