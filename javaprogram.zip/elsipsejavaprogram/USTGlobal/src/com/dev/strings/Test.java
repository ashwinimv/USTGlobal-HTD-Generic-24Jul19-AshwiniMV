package com.dev.strings;

import static com.dev.objectmethods.Demo.*; //when we made import statement as static no need to create the classname.methodname;

public class Test {  
	
	
	public static void main(String[] args) {
		System.out.println(i);
		System.out.println(str);
		print();
		name();
	}

}
