package com.dev.strings;

public class StringExample {

	public static void main(String[] args) {
		
		String str = "Hello";
		String str1;
		str1 = "hello world";
		String str2 = new String("Hello java");
		
		StringBuffer sb = new StringBuffer("Hello");
		StringBuilder sb1 = new StringBuilder("java");
		
		
		
		System.out.println(str);
		System.out.println(str1);
		System.out.println(str2);
		
		System.out.println("StringBuffer = "+sb);
		System.out.println("stringbuilder = "+sb1);
		System.out.println(sb+ " "+sb1);
		System.out.println("length = "+sb.length());
		System.out.println("capacity = "+sb.capacity());
		
		StringBuilder mystring =new StringBuilder("ggg");
		StringBuilder styyy= new StringBuilder("ggg");
		System.out.println(Integer.toHexString(mystring.hashCode()));
		System.out.println(Integer.toHexString(styyy.hashCode()));
		

	}

}
