package com.dev.inheritance;

public class DaughterMultilvel extends Father {
	static DaughterMultilvel d = new DaughterMultilvel();
	
	@Override
	public void printName() {
		String name = "nandini";
		System.out.println(name+ " "+d.name+" "+d.lastName);
	}

	public static void main(String[] args) {
		d.printName();
		

	}

}
