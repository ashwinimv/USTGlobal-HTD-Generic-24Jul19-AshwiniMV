package com.dev.inheritance;

public class MethodOverriding extends MethodOveridden {
	static MethodOverriding o = new MethodOverriding();
	
   @Override
	public  void printName() {
		System.out.println("child class");
		super.printName();
		
	}

	public static void main(String[] args) {
		o.printName();
	//	MethodOveridden.printName();//using dot operator we can access the static method
		

	}

}
