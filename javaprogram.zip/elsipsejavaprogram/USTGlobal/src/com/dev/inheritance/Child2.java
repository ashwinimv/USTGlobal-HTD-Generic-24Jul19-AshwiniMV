package com.dev.inheritance;

public class Child2 extends Child1{
	
	static Child2 c1 = new Child2();
	@Override
	public void printName() {
		
		
		//System.out.println(name + " "+super.name+" "+c1.lastName);
		super.printName();
	}
	

	public static void main(String[] args) {
		 c1.printName();
		

	}

}
