package com.dev.inheritance;

public class Child1 extends Parent{
	
	static Child1 c = new Child1();
	
	@Override
	public void printName() {
		
		//System.out.println(name + " "+f.lastName);
		//System.out.println(name + " "+f.name+" "+c.lastName);
		//System.out.println(name + " "+super.name+" "+c.lastName);
		super.printName();
	}
	

	public static void main(String[] args) {
		
        c.printName();
	}

}
