package com.dev.inheritance;

public class SubClass extends SuperClass{
	public SubClass() {
		//super(1);
		//super();
	}

	public static void main(String[] args) {
		SubClass s = new SubClass();
		
		

	}

}
