package com.dev.inheritance;

public class Parent {
	
	static Parent p = new Parent();
	String lastName = "Stark";
	 String name = "Torrhen";
	
	
	public static void main(String[] args) {
		p.printName();
		
	}
	public  void printName() {
		System.out.println(name + " "+p.lastName);
	}
	

}
