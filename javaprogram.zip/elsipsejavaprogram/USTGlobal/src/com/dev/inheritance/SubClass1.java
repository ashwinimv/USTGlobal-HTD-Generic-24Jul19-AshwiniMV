package com.dev.inheritance;

public class SubClass1 extends SuperClass {
	public SubClass1() {
		System.out.println("subclass called");
		
	}

	public static void main(String[] args) {
		SubClass1 s1 = new SubClass1();
		

	}

}
