package com.dev.inheritance;

public class MethodOveridden {
	static MethodOveridden o1= new MethodOveridden();
	
	
	public  void printName() { //final method can be inherited,not be override;
		System.out.println("parent class");
		
	}

	public static void main(String[] args) {
		o1.printName();
		

	}

}
