package com.dev.inheritance;

public class Mother extends GrandFather {
	static Mother m = new Mother();
	String name ="ashwini";

	@Override
	public void printName() {
		System.out.println(name+" "+m.name+" "+m.lastName);
	}


	public static void main(String[] args) {
		m.printName();


	}

}
