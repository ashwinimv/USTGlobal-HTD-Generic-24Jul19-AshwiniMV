package com.dev.arrays;

public class Arrays {

	public static void main(String[] args) {
		//declaration
		int []intArr;
		char[] charr;
		byte bytearr[];

		//creation
		intArr = new int[5];
		charr = new char[5];
		bytearr = new byte[5];

		//Declaration and creation
		int[] intArr1 = new int[5];
		System.out.println(intArr1);
		
		System.out.println("output"+charr);

		//declaration and creation,initialization
		int[] intArr2 =  { 10,20,30,40,50};
		System.out.println(intArr2[4]);
		System.out.println("length of an 2nd array = "+intArr2.length);

		//initialization
		intArr[0] = 1;
		intArr[1] = 2;
		intArr[2] = 3;
		intArr[3] = 4;
		intArr[4] = 5;

		charr[0] = 'a';
		charr[1] = 'b';
		charr[2] = 'c';
		charr[3] = 'd';
		charr[4] = 'e';

		bytearr[0] = 1;
		bytearr[1] = 2;
		bytearr[2] = 3;
		bytearr[3] = 4;
		bytearr[4] = 5;

		int res = intArr[0]*3;
		System.out.println("assddd"+res);

		int res1 = intArr[1]+3;
		System.out.println(res1);

		int res2 = intArr[2]-3;
		System.out.println(res2);

		int res3 = intArr[3]/3;
		System.out.println(res3);

		int res4 = intArr[4]%3;
		System.out.println(res4);

		/*System.out.println(charr[0]='a'+1);
		System.out.println(charr[1]='b'-1);
		System.out.println(charr[2]='c'*1);
		System.out.println(charr[3]='d'/1);
		System.out.println(charr[4]='e'%1);*/

		int a=22;

		int[] intArr3 = {11,22,33,44};
		for(int i=0;i<intArr3.length;i++)
		{
			if(intArr3[i]==a)
			{
				//System.out.println(intArr3[i]);
				System.out.println("found "+a);
				//break;
			}else {
				System.out.println("not found");
				break;
			}

		}

//		int b=10;
//		int[] intArr4 = {10,20,30,40};
//		for(int k=0;k<intArr4.length;k++) {
//			if(k==b)
//			{
//				System.out.println("valid index");
//				
//				for(int j=0;j<=k;j++) {
//					System.out.println(intArr4[j]);
//				}
//			}
//
//		}
		
		
		int[] intArr5 = {11,22,44,99,20};
		int index=78;
		if(index<intArr5.length) {
			System.out.println("valid index");
			for(int m=0;m<=index;m++) {
				System.out.println(intArr5[m]);
				
			}}else {
				System.out.println("invalid index");
			}
		
		int y=0;
		int z=intArr5.length-1;
		
		int midvalue=(y+z)/2;
		System.out.println(intArr5[midvalue]);
		
		int z1=intArr2.length-2;
		/*int midvalue2=(y+z1)/2;
		System.out.println(intArr5[midvalue2]);*/
		System.out.println(intArr5[z1]);
		
		






	}

}
