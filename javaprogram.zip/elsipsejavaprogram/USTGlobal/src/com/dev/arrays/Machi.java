package com.dev.arrays;

import com.dev.abstraction.Macha;

public class Machi {

	public static void main(String[] args) {
		Macha m = new Macha();
		int u = Macha.i;
		String s = Macha.str;
	  //  Macha.show();
		m.show();
		System.out.println(u);
		System.out.println(s);

	}

}
