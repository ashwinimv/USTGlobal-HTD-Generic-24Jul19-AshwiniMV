package com.dev.exception;

public class ExceptionHandlingTwo extends CustomException{
	public static void main(String[] args) throws CustomException {
		try {
			divide(10,0);
			
		} catch (Exception e) {
			throw new CustomException();
			//System.out.println(e.getMessage());
			//System.out.println( CustomException().getLocalizedMessage());
		}
		
	}
	public static int divide(int i,int j) {
		int res=i/j;
		System.out.println(res);
		return 1;
	}
	

}

