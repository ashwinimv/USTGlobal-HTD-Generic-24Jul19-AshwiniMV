package com.dev.exception;

public class ExceptionhandlingThrows {

//	public static void main(String[] args) throws Exception,NegativeArraySizeException {
//		s();
//		System.out.println("code after the exception");
//		
//
//	}
	public static void main(String[] args) throws  CustomException{
		try {
			s();
			
		} catch (CustomException e) {
			System.out.println("catch");
		}
	
		System.out.println("code after the exception");
		

	}
//	public static void s() throws Exception,NegativeArraySizeException{  //throws exception tells that this method or class might throw an exception
//	    StringBuffer sb = new StringBuffer(-1);
//		
//	}

	public static void s() throws CustomException{  //throws exception tells that this method or class might throw an exception
//	    StringBuffer sb = new StringBuffer(-1);
//		throw new CustomException();
		
		try {
			 StringBuffer sb = new StringBuffer(-1);
			 throw new CustomException();
			
		} catch (CustomException e) {
			System.out.println("catch block");
		}
	}

}
