package com.dev.exception;

public class MineException {
	public static void main(String[] args) {
		try {
			divide(10,0);
			s();
			
		} catch (ArithmeticException m) {
			System.out.println("Exception occured");
			//throw new CustomException();
			//System.out.println(new CustomException().getLocalizedMessage());
		}catch(NegativeArraySizeException x) {
			System.out.println("Array");
			
		}
		
		catch(Exception e) {
			System.out.println("jjjj");
			
		}
	}
	
	public static void s() throws CustomException{
	
			 StringBuffer sb = new StringBuffer(-1);
			
		
	   
		
	}
	public static int divide(int i,int j) {
		int res=i/j;
		System.out.println(res);
		return 1;
	}

}
