package com.dev.exception;

public class ExceptionHandling extends CustomException{

	public static void main(String[] args) throws CustomException {
//		try {
//			s();
//		}catch(Exception e) {
//			System.out.println("Exception occured");
//			e.printStackTrace();//it gives information about the exception
//			
//		}finally {
//			System.out.println("This is finally block");
//		}
//		System.out.println("code after exception");
//		
	//	s();
		//throw new CustomException();
		try {
			divide(10,5);
			s();
			
		} catch (ArithmeticException m) {
			System.out.println("Exception occured");
			//throw new CustomException();
			//System.out.println(new CustomException().getLocalizedMessage());
		}catch(NegativeArraySizeException x) {
			System.out.println("Array");
			
		}
		
		catch(Exception e) {
			System.out.println("jjjj");
			
		}

	}
	
	public static void s() throws CustomException{
		try {
			 StringBuffer sb = new StringBuffer(-1);
			
		}catch(Exception e) {
			//new CustomException().printStackTrace();
			System.out.println(e.getMessage());
			System.out.println(new CustomException().getLocalizedMessage());
			
		}
	   
		
	}
	public static int divide(int i,int j) {
		int res=i/j;
		System.out.println(res);
		return 1;
	}
	

}
