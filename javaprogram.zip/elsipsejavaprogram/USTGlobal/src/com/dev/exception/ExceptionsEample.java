package com.dev.exception;

public class ExceptionsEample {

	public static void main(String[] args) {
		double d = 10.0;
		double q = 0.0;
		System.out.println("Result = "+d/q);
		s();
		//StringBuffer sb= new StringBuffer(-1);
		System.out.println("print statements");

	}
	public static void s() {
		//StringBuffer sb = new StringBuffer(-1);
		
	}
	
	public static void t() {
	s();
		
	}
	

}
