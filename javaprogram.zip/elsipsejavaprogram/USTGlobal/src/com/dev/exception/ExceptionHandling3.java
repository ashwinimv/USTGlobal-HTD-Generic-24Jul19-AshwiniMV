package com.dev.exception;

public class ExceptionHandling3 {

	public static void main(String[] args) {
	  try {
		  s();
		  System.out.println("no exception for s()");
		  int res=divide(10,0);
		  System.out.println("no exceptio for divide()");
		  System.out.println(res);
	  }catch(NegativeArraySizeException e) {
		  System.err.println("exceptioncaught in catch block");
		  System.out.println("getMessage():"+e.getMessage());
		//  e.printStackTrace();

	}catch(ArithmeticException e) {
		System.err.println("exception caught in catch block");
		System.err.println("getMessage()"+e.getMessage());
		
	}finally {
		System.out.println("finally block");
	}
	
	
}
	public static int divide(int i,int j) {
		int res=i/j;
		System.out.println(res);
		return 1;
	}

	public static void s() {
		int i=-1;
		if(i<0) {
			System.out.println("jjj");
		}
		
		
		StringBuffer sb = new StringBuffer(-1);
	}
}
