package com.dev.my;

import java.util.HashSet;

public class MineImp implements Mine {
	
	HashSet<Dog> hs= new HashSet<Dog>();

	@Override
	public boolean addDog(Dog dog) {
		if(dog!=null) {
			hs.add(dog);
			return true;
			
		}
		return false;
	}

	@Override
	public void getDog() {
		// TODO Auto-generated method stub
		System.out.println(hs);
		
	}

}
