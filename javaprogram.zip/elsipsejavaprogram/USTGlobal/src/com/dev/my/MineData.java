package com.dev.my;

public class MineData {
	public static void main(String[] args) {
		MineImp m = new MineImp();
		
		Dog d = new Dog();
		d.setA(1);
		
		boolean b=m.addDog(d);
		System.out.println(b);
		
		
		m.getDog();
		
		
	}
	
	

}
