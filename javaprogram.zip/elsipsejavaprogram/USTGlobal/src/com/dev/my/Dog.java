package com.dev.my;

public class Dog {
	
	
	private int a;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	@Override
	public String toString() {
		return "Dog [a=" + a + "]";
	}

}
