package com.dev.my;

public interface Mine {
	
	public boolean addDog(Dog dog);
	public void getDog();

}
