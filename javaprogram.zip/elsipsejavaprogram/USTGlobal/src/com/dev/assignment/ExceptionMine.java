package com.dev.assignment;

public class ExceptionMine{
	public static int divideByZero(int a,int b) {
		int i =a/b;
		System.out.println(i);
		
		return i;
	}
	
	public static void main(String[] args) {
		try {
			divideByZero(10,0);
			
		}catch(Exception e) {
			System.out.println("bhdghd");
			System.err.println("getMessage()"+e.getMessage());
			
		}
	}
}