package com.dev.assignment;
import java.util.Scanner;

public class ReverseString {

	public static void main(String[] args) {
    
      String str="hello";
      
       int i;
       System.out.println(str.length());
       String reverse="";
       for(i=str.length()-1;i>=0;i--) {
    	   reverse = reverse +str.charAt(i);
    	   
       }
       System.out.println("reverse string is="+reverse);
       

	}

}
