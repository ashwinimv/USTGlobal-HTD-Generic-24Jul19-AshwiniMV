package com.dev.assignment;

public class ReverseArray {

	public static void main(String[] args) {
		int a[]= {10,20,30,40,50,60};
		
		for(int j=0;j<a.length-1;j++) {
			System.out.println("array"+a[j]);
		}
		
		for(int i=a.length-1;i>=0;i--) {
			System.out.println("reverse array"+a[i]);
		}

	}

}
