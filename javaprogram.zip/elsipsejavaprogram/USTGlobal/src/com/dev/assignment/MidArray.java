package com.dev.assignment;

public class MidArray {

	public static void main(String[] args) {
		int a[]= {10,20,30,40,50,60,70};
		
		int y=0;
		int z=a.length-1;
		
		int midvalue=(y+z)/2;
		System.out.println(a[midvalue]);
		
		int b=a.length;
		
		
		System.out.println("second element of an array = "+a[b-2]);
		
		int c=a.length-2;
		int mid=(y+c)/2;
		System.out.println("mid value : "+a[mid]);
		
		int sum=a[0]+a[midvalue]+a[c];
		System.out.println(sum);
		
		

	}

}
