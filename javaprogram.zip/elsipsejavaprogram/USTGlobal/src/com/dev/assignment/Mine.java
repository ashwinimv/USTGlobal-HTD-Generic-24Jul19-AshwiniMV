package com.dev.assignment;

public class Mine {
	static int i =0101;//it takes in octane;
	static int j =0011;
	static int k =10;
	static int m=15;
	
	//static int i =0101;
	public static void main(String[] args) {
		System.out.println(k++);
		System.out.println(i);
		System.out.println(j);
		System.out.println(k+m);
		System.out.println(++k + m++);
		String s1="ashu";
		String s2="asd";
		System.out.println(s2=s1);
		
	}
	

}
