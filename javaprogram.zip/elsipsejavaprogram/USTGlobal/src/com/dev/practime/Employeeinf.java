package com.dev.practime;

public interface Employeeinf {
	
	public Employee addEmployee(String k,Employee b);
	public Employee removeEmployee(String k);

}
