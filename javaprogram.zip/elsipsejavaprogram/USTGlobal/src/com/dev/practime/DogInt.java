package com.dev.practime;

public interface DogInt {
	
	public Dogs addDog(String k,Dogs b);
	public Dogs removeDog(String k);

}
