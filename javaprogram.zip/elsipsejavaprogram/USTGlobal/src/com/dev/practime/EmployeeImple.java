package com.dev.practime;

import java.util.HashMap;

public class EmployeeImple implements Employeeinf {
	HashMap<String,Employee> hm = new HashMap<String,Employee>();

	@Override
	public Employee addEmployee(String k, Employee b) {
		if(b!=null) {
			hm.put(k,b);
			Employee nh=hm.put(k, b);
			if(nh!=null) {
				return nh;
			}
		}
		return null;
	}

	@Override
	public Employee removeEmployee(String k) {
		Employee nh=hm.remove(k);
		return null;
	}
	

}
