package com.dev.practime;

import java.util.HashMap;

public class DogsImpl implements DogInt {
	HashMap<String, Dogs> hm = new HashMap<String, Dogs>();

	@Override
	public Dogs addDog(String k, Dogs b) {
		if(b!=null) {
			hm.put(k,b);
			Dogs bu=hm.put(k, b);
			if(bu!=null) {
				return bu;
			}
			
			
		}
		return null;
	}

	@Override
	public Dogs removeDog(String k) {
		Dogs f =hm.remove(k);
		return null;
	}

	public static void main(String[] args) {
		DogsImpl mm = new DogsImpl();
		
		
		
		
	}
}
