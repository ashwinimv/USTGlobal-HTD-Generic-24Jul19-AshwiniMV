package com.dev.practime;

import java.util.HashMap;

public class DogdData {

	public static void main(String[] args) {
		DogsImpl mm = new DogsImpl();
		//HashMap<String, Dogs> hm = new HashMap<String, Dogs>();
		Dogs du =new Dogs();
		du.setAge(1);
		du.setName("hhhh");
		
		Dogs du1 =new Dogs();
		du1.setAge(2);
		du1.setName("hhhhjjj");
		
	 //  Dogs b= hm.put("1", du);
//	    hm.put("2", du1);
	   
	   Dogs b1 = mm.addDog("5", du);
	   
	   System.out.println(b1);
		
	
	//	System.out.println(b);
	//	System.out.println(hm);
	
		
		



	}

}
