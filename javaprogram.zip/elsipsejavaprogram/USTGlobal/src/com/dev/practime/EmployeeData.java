package com.dev.practime;

public class EmployeeData {
	public static void main(String[] args) {
		EmployeeImple mm = new EmployeeImple();
		Employee e = new Employee();
		e.setEmail("asjsjfh");
		e.setEmpid(1);
		e.setEname("ashwini");
		e.setPassword("122333");
		e.setSalary(1233555);
		
		Employee e1 = new Employee();
		e1.setEmail("asjsjfh");
		e1.setEmpid(1);
		e1.setEname("ashwini");
		e1.setPassword("122333");
		e1.setSalary(1233555);
		
		Employee b1=mm.addEmployee("1", e);
		Employee b2=mm.addEmployee("2", e1);
		System.out.println("jj"+b1);
				
	}

}
