package com.dev.polymorphism;

public class MethodOveridden {

	
	public void printName() {
		System.out.println("run time polymorphism");
	}
	public static void main(String[] args) {
		MethodOveridden m = new MethodOveridden();
		m.printName();

	}

}
