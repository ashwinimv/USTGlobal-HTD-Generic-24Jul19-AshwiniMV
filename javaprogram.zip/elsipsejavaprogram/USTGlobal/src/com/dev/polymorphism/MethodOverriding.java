package com.dev.polymorphism;

public class MethodOverriding extends MethodOveridden{
	@Override
	public void printName() {
		System.out.println("child class , run time polymorphism");
		super.printName();
	}

	public static void main(String[] args) {
		MethodOverriding m2= new MethodOverriding();
		m2.printName();
		

	}

}
