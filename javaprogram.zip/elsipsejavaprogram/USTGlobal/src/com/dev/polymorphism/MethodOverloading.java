package com.dev.polymorphism;

public class MethodOverloading {
	
	public int add(int i ,int j) {
		System.out.println("addition of 2 numbers = "+(i+j));
		System.out.println("compile time polymorphism");
		return i+j;
		
	}
	public int add(int i ,int j,int k) {
		System.out.println("addition of 2 numbers = "+(i+j+k));
		return i+j+k;
		
	}

	public static void main(String[] args) {
		MethodOverloading m = new MethodOverloading();
		m.add(10, 20);
		m.add(10, 20,30);
		
		

	}

}
