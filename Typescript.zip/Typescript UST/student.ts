export class Student{
    name : string='ashu';
    printDetails(){
        console.log(this.name);
    }
}