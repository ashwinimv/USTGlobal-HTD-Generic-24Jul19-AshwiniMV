var rectangleOperations;
(function (rectangleOperations) {
    var retangle;
    (function (retangle) {
        function area(length, breadth) {
            console.log('area of rectangle' + length * breadth);
        }
        retangle.area = area;
    })(retangle = rectangleOperations.retangle || (rectangleOperations.retangle = {}));
})(rectangleOperations || (rectangleOperations = {}));
