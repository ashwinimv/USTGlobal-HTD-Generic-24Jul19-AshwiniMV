function printConstructor(cons: Function){
    console.log(cons);
}//usually we dont create decorators.....i want madethis function as decorators


@printConstructor
class Sample{
    constructor(){
        console.log("hi hello");
    }
}