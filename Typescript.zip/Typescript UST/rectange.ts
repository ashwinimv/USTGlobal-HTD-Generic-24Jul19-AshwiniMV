namespace rectangleOperations{
    export namespace retangle{
        export function area(length :number,breadth :number){
            console.log('area of rectangle'+length*breadth);
        }

     }
}
