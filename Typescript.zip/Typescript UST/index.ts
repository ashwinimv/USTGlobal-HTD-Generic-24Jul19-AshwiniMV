// let myName = 'ashwini';
// console.log(myName);

// let num=20;
// console.log(num);

// let num1=30;
// console.log(num1);

// let name1: string = 'ashwiii';
// console.log(name);

// let name3: string = 'ashwiii';
// console.log(name);

// let company;
// company="USt";
// company=23; // it automatically take any type
// console.log(company);

let sample : number |  boolean;
sample=10;
sample=true
console.log(sample);

let myArray:string[]= ['hjd','djhv']; 
console.log(myArray);

let myTuple: [string,number,boolean] = ['ashwini',25,true]; //whatever the data mention in th tuple we have to pass in the same order
console.log(myTuple);

enum Colors {
    red=303,
    green,
    blue,
    black

}
console.log(Colors.black);//it print index value ,if we give the value for red it print 306it goes in a incremental order

enum Colors1 {
    red= 'Danger',
    green = 'success',
    blue = 'Primary',
    black = 'dark'

}
console.log(Colors1.black);


class Person {
    name : string = 'Ashwini';
    age : number =23;
}

let person1 = new Person();
console.log(person1.name);

class Person2 {
    name : string;
    age : number;
    constructor(personName:string, personAge:number){ //constructor calling
         this.name=personName;
         this.age=personAge;
    }
}

let person2 = new Person2('Priya',22);
console.log(person2.name);
console.log(person2.age);

class Person3{
    constructor(public personName:string, public personAge:number){ 
        // this.name=personName; //we cannot write directly we can access out side the class because of public
        // this.age=personAge;

    }

}

let person3 = new Person3('Priya',22);
console.log(person3.personAge);
console.log(person3.personName);

let name5="ashu";
name5=null; //strictNullChecks": true, is commented in json then it not show error or if we give flase also no error , if we uncomment andtrue it show error

class Car{
    brand : string = 'Audi';
    static model : string = 'x5';
}

let audiCar = new Car();
console.log(audiCar.brand);//nonstatic
console.log(Car.model);//static

class Car1{
    constructor(public brand:string,public model:string){

    }
}

let audiCar1 = new Car1('Audii','x6');
console.log(audiCar1.brand);
console.log(audiCar1.model);

let benzCar: Car1={
    brand: 'Benz',
    model : '002'
}

console.log(benzCar.brand);
console.log(benzCar.model);

console.log("****************************inheritance");

class Persons{
    constructor(public name:string,public age:number){

    }
}
class Student1 extends Persons{
    salary:number=25001;
    constructor(public myName1:string,public myAge1:number,public USN:number){
        super(myName1,myAge1);
    }
}


let persons1 = new Persons('guldu',25);
let student2 = new Student1('ashwini',23,123456007);
console.log(student2.salary);
// console.log(person1.name);

console.log("/////////////");


class Priya{
    constructor(public name6:string,public age5:number,public degree ?:string){ //? is uesd to make optional

    }
}

let priya1:Priya ={
    name6:'prajna',
    age5:36

}
// console.log(priya1.name6);
let priya2:Priya ={
    name6:'pooja',
    age5:34,
    degree:'Engineering'
}
console.log(priya2.name6);
console.log(priya2.degree);
console.log(priya2.age5);



console.log("interface***********");

interface Students{
    name7 : string;
    age6 : number;
    printDetails():void;
}
class Personns implements Students{
    name7= 'megha';
    age6= 26;
    printDetails(){
        console.log("name is="+this.name7+'age is'+this.age6);
    }
}

let personns1 =new Personns();
personns1.printDetails();

let studennts:Students={
    name7:'jamuna',
    age6: 25,
    printDetails : ()=>{
        console.log("name is="+studennts.name7+'age is'+studennts.age6);
    }
}

console.log("generics********");
function getArray(items:string[]){
    return new Array().concat(items);

}

console.log(getArray(['aaa','ddd']));

console.log("generics now*****");
function getArray1<p>(items:p[]):p[]{
    return new Array<p>().concat(items);
}

let strArray = getArray1<string>(['hdhhf','hdh','hdhijdvj']);
strArray.push('jhjjj');
console.log(strArray);
let numArray = getArray1<number>([233,2222]);
numArray.push(5555);
console.log(numArray);

console.log('namespace888888');

namespace Mathoperations {
    const PI=3.14;
   export function circumferenceOfCircle(radius :number){
        console.log("the circumference circle"+2*PI*radius);
    }
    export function areaOfcircle(radius:number){
        console.log("the area"+PI*radius*radius);
    }
}

Mathoperations.circumferenceOfCircle(3);
Mathoperations.areaOfcircle(3);

console.log("nestednamespace");


namespace Mathoperations1 {
    export namespace Circle{

   
    const PI=3.14;
   export function circumferenceOfCircle(radius :number){
        console.log("the circumference circle"+2*PI*radius);
    }
    export function areaOfcircle(radius:number){
        console.log("the area"+PI*radius*radius);
    }
}
}

// Mathoperations.Circle.circumferenceOfCircle(3);
// Mathoperations.Circle.areaOfcircle(3);

console.log("99999999999");





