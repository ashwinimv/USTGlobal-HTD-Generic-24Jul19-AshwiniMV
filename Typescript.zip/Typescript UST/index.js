// let myName = 'ashwini';
// console.log(myName);
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
// let num=20;
// console.log(num);
// let num1=30;
// console.log(num1);
// let name1: string = 'ashwiii';
// console.log(name);
// let name3: string = 'ashwiii';
// console.log(name);
// let company;
// company="USt";
// company=23; // it automatically take any type
// console.log(company);
var sample;
sample = 10;
sample = true;
console.log(sample);
var myArray = ['hjd', 'djhv'];
console.log(myArray);
var myTuple = ['ashwini', 25, true]; //whatever the data mention in th tuple we have to pass in the same order
console.log(myTuple);
var Colors;
(function (Colors) {
    Colors[Colors["red"] = 303] = "red";
    Colors[Colors["green"] = 304] = "green";
    Colors[Colors["blue"] = 305] = "blue";
    Colors[Colors["black"] = 306] = "black";
})(Colors || (Colors = {}));
console.log(Colors.black); //it print index value ,if we give the value for red it print 306it goes in a incremental order
var Colors1;
(function (Colors1) {
    Colors1["red"] = "Danger";
    Colors1["green"] = "success";
    Colors1["blue"] = "Primary";
    Colors1["black"] = "dark";
})(Colors1 || (Colors1 = {}));
console.log(Colors1.black);
var Person = /** @class */ (function () {
    function Person() {
        this.name = 'Ashwini';
        this.age = 23;
    }
    return Person;
}());
var person1 = new Person();
console.log(person1.name);
var Person2 = /** @class */ (function () {
    function Person2(personName, personAge) {
        this.name = personName;
        this.age = personAge;
    }
    return Person2;
}());
var person2 = new Person2('Priya', 22);
console.log(person2.name);
console.log(person2.age);
var Person3 = /** @class */ (function () {
    function Person3(personName, personAge) {
        // this.name=personName; //we cannot write directly we can access out side the class because of public
        // this.age=personAge;
        this.personName = personName;
        this.personAge = personAge;
    }
    return Person3;
}());
var person3 = new Person3('Priya', 22);
console.log(person3.personAge);
console.log(person3.personName);
var name5 = "ashu";
name5 = null; //strictNullChecks": true, is commented in json then it not show error or if we give flase also no error , if we uncomment andtrue it show error
var Car = /** @class */ (function () {
    function Car() {
        this.brand = 'Audi';
    }
    Car.model = 'x5';
    return Car;
}());
var audiCar = new Car();
console.log(audiCar.brand); //nonstatic
console.log(Car.model); //static
var Car1 = /** @class */ (function () {
    function Car1(brand, model) {
        this.brand = brand;
        this.model = model;
    }
    return Car1;
}());
var audiCar1 = new Car1('Audii', 'x6');
console.log(audiCar1.brand);
console.log(audiCar1.model);
var benzCar = {
    brand: 'Benz',
    model: '002'
};
console.log(benzCar.brand);
console.log(benzCar.model);
console.log("****************************inheritance");
var Persons = /** @class */ (function () {
    function Persons(name, age) {
        this.name = name;
        this.age = age;
    }
    return Persons;
}());
var Student1 = /** @class */ (function (_super) {
    __extends(Student1, _super);
    function Student1(myName1, myAge1, USN) {
        var _this = _super.call(this, myName1, myAge1) || this;
        _this.myName1 = myName1;
        _this.myAge1 = myAge1;
        _this.USN = USN;
        _this.salary = 25001;
        return _this;
    }
    return Student1;
}(Persons));
var persons1 = new Persons('guldu', 25);
var student2 = new Student1('ashwini', 23, 123456007);
console.log(student2.salary);
// console.log(person1.name);
console.log("/////////////");
var Priya = /** @class */ (function () {
    function Priya(name6, age5, degree) {
        this.name6 = name6;
        this.age5 = age5;
        this.degree = degree;
    }
    return Priya;
}());
var priya1 = {
    name6: 'prajna',
    age5: 36
};
// console.log(priya1.name6);
var priya2 = {
    name6: 'pooja',
    age5: 34,
    degree: 'Engineering'
};
console.log(priya2.name6);
console.log(priya2.degree);
console.log(priya2.age5);
console.log("interface***********");
var Personns = /** @class */ (function () {
    function Personns() {
        this.name7 = 'megha';
        this.age6 = 26;
    }
    Personns.prototype.printDetails = function () {
        console.log("name is=" + this.name7 + 'age is' + this.age6);
    };
    return Personns;
}());
var personns1 = new Personns();
personns1.printDetails();
var studennts = {
    name7: 'jamuna',
    age6: 25,
    printDetails: function () {
        console.log("name is=" + studennts.name7 + 'age is' + studennts.age6);
    }
};
console.log("generics********");
function getArray(items) {
    return new Array().concat(items);
}
console.log(getArray(['aaa', 'ddd']));
console.log("generics now*****");
function getArray1(items) {
    return new Array().concat(items);
}
var strArray = getArray1(['hdhhf', 'hdh', 'hdhijdvj']);
strArray.push('jhjjj');
console.log(strArray);
var numArray = getArray1([233, 2222]);
numArray.push(5555);
console.log(numArray);
console.log('namespace888888');
var Mathoperations;
(function (Mathoperations) {
    var PI = 3.14;
    function circumferenceOfCircle(radius) {
        console.log("the circumference circle" + 2 * PI * radius);
    }
    Mathoperations.circumferenceOfCircle = circumferenceOfCircle;
    function areaOfcircle(radius) {
        console.log("the area" + PI * radius * radius);
    }
    Mathoperations.areaOfcircle = areaOfcircle;
})(Mathoperations || (Mathoperations = {}));
Mathoperations.circumferenceOfCircle(3);
Mathoperations.areaOfcircle(3);
console.log("nestednamespace");
var Mathoperations1;
(function (Mathoperations1) {
    var Circle;
    (function (Circle) {
        var PI = 3.14;
        function circumferenceOfCircle(radius) {
            console.log("the circumference circle" + 2 * PI * radius);
        }
        Circle.circumferenceOfCircle = circumferenceOfCircle;
        function areaOfcircle(radius) {
            console.log("the area" + PI * radius * radius);
        }
        Circle.areaOfcircle = areaOfcircle;
    })(Circle = Mathoperations1.Circle || (Mathoperations1.Circle = {}));
})(Mathoperations1 || (Mathoperations1 = {}));
// Mathoperations.Circle.circumferenceOfCircle(3);
// Mathoperations.Circle.areaOfcircle(3);
console.log("99999999999");
