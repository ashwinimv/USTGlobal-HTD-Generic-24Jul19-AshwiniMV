import { Student } from './Student';

let student1= new Student();
student1.printDetails();