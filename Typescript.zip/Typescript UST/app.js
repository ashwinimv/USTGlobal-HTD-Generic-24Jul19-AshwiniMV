/// <reference path="./index.ts" />
/// <reference path="./rectange.ts" />
Mathoperations1.Circle.circumferenceOfCircle(3);
rectangleOperations.retangle.area(5, 5);
