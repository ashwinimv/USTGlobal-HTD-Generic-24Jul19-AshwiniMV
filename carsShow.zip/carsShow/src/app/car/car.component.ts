import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-car',
  templateUrl: './car.component.html',
  styleUrls: ['./car.component.css']
})
export class CarComponent implements OnInit {
  carData: any='';
  Cars=[{
    brand:'Audi',
    img:'https://cdn.pixabay.com/photo/2014/06/14/05/54/car-368636__340.jpg',
    description:'The company name is based on the Latin translation of the surname of the founder, August Horch. "Horch", meaning "listen" in German, becomes "audi" in Latin. The four rings of the Audi logo each represent one of four car companies that banded together to create Audis predecessor company, Auto Union.'
     },
     {
      brand:'LAMORGINI',
      img:'https://cdn.pixabay.com/photo/2016/04/28/20/58/lamborghini-1359712__340.jpg',
      description:' is an Italian brand and manufacturer of luxury sports cars and SUVs based in SantAgata Bolognese and tractors Lamborghini Trattori in Pieve di Cento, Italy. The company is owned by the Volkswagen Group through its subsidiary Audi.'
      
     },
     {
      brand:'BENZ',
      img:'https://cdn.pixabay.com/photo/2016/04/19/06/03/mercedes-1338063__340.jpg',
      description:'Mercedes-Benz (German: [mɛɐ̯ˈtseːdəsˌbɛnts, -dɛs-]) is a German global automobile marque and a division of Daimler AG. The brand is known for luxury vehicles, buses, coaches, and trucks. The headquarters is in Stuttgart, Baden-Württemberg'
      
     },
     {
      brand:'BMW',
      img:'https://image.shutterstock.com/image-photo/saintpetersburg-russia-september-16-2017-260nw-1017684391.jpg',
      description:'is a German multinational company which produces automobiles and motorcycles. The company was founded in 1916 as a manufacturer of aircraft engines, which it produced from 1917 until 1918 and again from 1933 to 1945.'
      
     },
     {
      brand:'JAGUAR',
      img:'https://cdn.pixabay.com/photo/2017/06/05/17/59/auto-2374724__340.jpg',
      description:'Jaguar Cars is a brand of cars made by Jaguar Land Rover. This is a British car builder, owned by the Indian builder Cans Tata Motors since the beginning of 2008. It was established in 1922 by William Lyons. It was renamed Jaguar in 1935.'
      
     },
     {
      brand:'MERCURY',
      img:'https://cdn.pixabay.com/photo/2016/09/19/22/10/mercury-1681443__340.jpg',
      description:'Mercury (automobile) ... Mercury is a defunct division of the U.S. automobile manufacturer Ford Motor Company. Marketed as an entry-level premium brand for nearly its entire existence, Mercury was created in 1938 by Edsel Ford to bridge the price gap between the Ford and Lincoln vehicle lines.'
      
     },
    
     {
      brand:'FERRARI',
      img:'https://cdn.pixabay.com/photo/2014/09/07/22/34/car-race-438467__340.jpg',
      description:'Ferrari is an Italian luxury sports car manufacturer based in Maranello. Founded by Enzo Ferrari in 1939 out of Alfa Romeos race division as Auto Avio Costruzioni, the company built its first car in 1940. ... In 2014 Ferrari was rated the worlds most powerful brand by Brand Finance'
      
     },
     
    
     
     ];





  constructor() { }
  sendCar(car){
    this.carData = car;


  }

  ngOnInit() {
  }

}
